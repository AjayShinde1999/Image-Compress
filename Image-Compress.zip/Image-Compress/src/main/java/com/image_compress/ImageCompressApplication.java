package com.image_compress;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImageCompressApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImageCompressApplication.class, args);
	}

}
