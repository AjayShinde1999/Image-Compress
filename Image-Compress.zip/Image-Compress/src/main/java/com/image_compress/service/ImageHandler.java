package com.image_compress.service;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.ImageOutputStream;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Iterator;

@Component
public class ImageHandler {

    private static final long MAX_SIZE_BYTES = 5 * 1024 * 1024;
    private static final float MIN_QUALITY = 0.1f;

    // Compress the image to ensure it is ≤ 20MB
    public byte[] compressImageIfNeeded(MultipartFile file) throws IOException {
        if (file.getSize() <= MAX_SIZE_BYTES) {
            return file.getBytes(); // Return as is if size is already within limit
        }

        // File is larger than 20MB, compress it iteratively
        return compressImageIteratively(file);
    }

    private byte[] compressImageIteratively(MultipartFile file) throws IOException {
        BufferedImage originalImage = ImageIO.read(file.getInputStream());
        float quality = 0.9f; // Start with high quality
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        while (true) {
            baos.reset(); // Clear the output stream
            compressImage(originalImage, baos, quality);

            if (baos.size() <= MAX_SIZE_BYTES || quality <= MIN_QUALITY) {
                break; // Stop if size is within the limit or quality is too low
            }

            quality -= 0.1f; // Reduce quality for the next iteration
        }

        return baos.toByteArray();
    }

    private void compressImage(BufferedImage image, ByteArrayOutputStream baos, float quality) throws IOException {
        Iterator<ImageWriter> writers = ImageIO.getImageWritersByFormatName("jpg");
        if (!writers.hasNext()) {
            throw new IllegalStateException("No writers found for JPEG format");
        }

        ImageWriter writer = writers.next();

        try (ImageOutputStream ios = ImageIO.createImageOutputStream(baos)) {
            writer.setOutput(ios);
            ImageWriteParam param = writer.getDefaultWriteParam();

            if (param.canWriteCompressed()) {
                param.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);
                param.setCompressionQuality(quality);
            }

            writer.write(null, new IIOImage(image, null, null), param);
        } finally {
            writer.dispose();
        }
    }
}
