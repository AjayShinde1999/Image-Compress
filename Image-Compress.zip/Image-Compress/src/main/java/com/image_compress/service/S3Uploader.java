package com.image_compress.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.io.IOException;
import java.net.URL;

@Service
public class S3Uploader {

    @Autowired
    private S3Client s3Client;

    @Value("${cloud.aws.bucket-name}")
    private String bucketName;

    @Autowired
    private ImageHandler imageHandler;

    public String uploadFile(MultipartFile file) throws IOException {
        byte[] processedImage = imageHandler.compressImageIfNeeded(file);

        // Construct the S3 key (file name)
        String fileName = "attachments/" + file.getOriginalFilename();

        // Upload to S3
        s3Client.putObject(PutObjectRequest.builder()
                        .bucket(bucketName)
                        .key(fileName)
                        .build(),
                RequestBody.fromBytes(processedImage));

        // Generate the file's URL after upload
        URL url = s3Client.utilities().getUrl(builder -> builder.bucket(bucketName).key(fileName).build());

        // Return the public URL of the uploaded file
        return url.toString();
    }
}
